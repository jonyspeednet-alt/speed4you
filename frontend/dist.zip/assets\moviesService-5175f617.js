import{a as e}from"./apiClient-3a66fbd3.js";const a={getAll:a=>e(`/movies?${new URLSearchParams(a)}`),getById:a=>e(`/movies/${a}`)};export{a as m};

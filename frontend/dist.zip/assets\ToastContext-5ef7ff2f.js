import{r}from"./react-vendor-c37b7f41.js";const t=r.createContext(null);export{t as T};
